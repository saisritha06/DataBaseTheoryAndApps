import re

from flask import Flask, request, render_template, session, redirect
import datetime
import os.path
import pymongo
from bson import ObjectId

my_client = pymongo.MongoClient("mongodb://localhost:27017/")
my_db = my_client["OPS"]
app = Flask(__name__)
app.secret_key = "ops"
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
Admin_col = my_db['Admin']
Doctor_col = my_db['Doctor']
Medicine_category = my_db['Medicine Category']
Medicine_col = my_db['Medicine']
Prescription_col = my_db['Prescription']
Order_col = my_db['Order']
Patient_col = my_db['Patient']
Payment_col = my_db['Payment']
Delivery_boy_col = my_db['Delivery Boy']


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/logout")
def logout():
    session.clear()
    return render_template("index.html")


@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")


@app.route("/admin_login1")
def admin_login1():
    email = request.args.get("email")
    password = request.args.get("password")
    query = {"email": email, "password": password}
    if Admin_col.count_documents({}) == 0:
        Admin_col.insert_one({"email": "admin@gmail.com", "password": "admin", "role": "Admin"})
    admin = Admin_col.find_one(query)

    if admin is not None:
        session['admin_id'] = str(admin['_id'])
        session['role'] = 'Admin'
        return render_template("admin_home.html")
    else:
        return render_template("message.html", msg="Invalid Login", color="text-red")


@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")


@app.route("/doctor_login")
def doctor_login():
    return render_template("doctor_login.html")


@app.route("/doctor_login1")
def doctor_login1():
    email = request.args.get("email")
    password = request.args.get("password")
    query = {"email": email, "password": password}
    count = Doctor_col.count_documents(query)
    if count > 0:
        query = {"email": email, "password": password}
        doctor = Doctor_col.find_one(query)
        if doctor['status'] == "Verified":
            session['doctor_id'] = str(doctor['_id'])
            session['role'] = 'doctor'
            return render_template("doctor_home.html")
        else:
            return render_template("message.html", msg="Account not verified yet")
    else:
        return render_template("message.html", msg="Doctor doesn't exist")


@app.route("/add_delivery_boy")
def add_delivery_boy():
    delivery_boys = Delivery_boy_col.find()
    return render_template("add_delivery_boy.html", delivery_boys=delivery_boys)


@app.route("/add_delivery_boy1")
def add_delivery_boy1():
    name = request.args.get("name")
    email = request.args.get("email")
    phone = request.args.get("phone")
    password = request.args.get("password")
    query = {"$or": [{"email": email}, {"phone": phone}]}
    count = Delivery_boy_col.count_documents(query)
    if count == 0:
        query = {"name": name, "email": email, "phone": phone,"password": password}
        Delivery_boy_col.insert_one(query)
        return render_template("message.html", msg="Delivery boy added!")
    else:
        return render_template("message.html", msg="Delivery boy already exist")


@app.route("/delivery_boy_login")
def delivery_boy_login():
    return render_template("delivery_boy_login.html")


@app.route("/delivery_boy_login1")
def delivery_boy_login1():
    email = request.args.get("email")
    password = request.args.get("password")
    query = {"email": email, "password": password}
    count = Delivery_boy_col.count_documents(query)
    if count > 0:
        query = {"email": email, "password": password}
        delivery_boy = Delivery_boy_col.find_one(query)
        session['delivery_boy_id'] = str(delivery_boy['_id'])
        session['role'] = 'delivery boy'
        return render_template("delivery_boy_home.html", delivery_boy=delivery_boy)
    else:
        return render_template("message.html", msg="Invalid Login")


@app.route("/delivery_boy_home")
def delivery_boy_home():
    return render_template("delivery_boy_home.html")


@app.route("/patient_login")
def patient_login():
    return render_template("patient_login.html")


@app.route("/patient_login1")
def patient_login1():
    email = request.args.get("email")
    password = request.args.get("password")
    query = {"email": email, "password": password}
    count = Patient_col.count_documents(query)
    if count > 0:
        query = {"email": email, "password": password}
        patient = Patient_col.find_one(query)
        session['patient_id'] = str(patient['_id'])
        session['role'] = 'patient'
        return render_template("patient_home.html", patient=patient)
    else:
        return render_template("message.html", msg="Patient doesn't exist")


@app.route("/doctor_registration")
def doctor_registration():
    return render_template("doctor_registration.html")


@app.route("/add_doctor")
def add_doctor():
    name = request.args.get("name")
    email = request.args.get("email")
    phone = request.args.get("phone")
    designation = request.args.get("designation")
    Address = request.args.get("Address")
    password = request.args.get("password")
    query = {"email": email, "phone": phone}
    count = Doctor_col.count_documents(query)
    if count == 0:
        query = {"name": name, "email": email, "phone": phone, "designation": designation, "Address": Address,
                 "password": password, "status": "Not Verified"}
        Doctor_col.insert_one(query)
        return render_template("message.html", msg="Registration Successful!")
    else:
        return render_template("message.html", msg="Doctor already registered")


@app.route("/patient_registration")
def patient_registration():
    return render_template("patient_registration.html")


@app.route("/add_patient")
def add_patient():
    name = request.args.get("name")
    email = request.args.get("email")
    phone = request.args.get("phone")
    Address = request.args.get("Address")
    password = request.args.get("password")
    query = {"email": email, "phone": phone}
    count = Patient_col.count_documents(query)
    if count == 0:
        query = {"name": name, "email": email, "phone": phone, "Address": Address,
                 "password": password}
        Patient_col.insert_one(query)
        return render_template("message.html", msg="Registration Successful!")
    else:
        return render_template("message.html", msg="Patient already registered")


@app.route("/doctor_home")
def doctor_home():
    return render_template("doctor_home.html")


@app.route("/patient_home")
def patient_home():
    patient_id = session['patient_id']
    query = {"_id": ObjectId(patient_id)}
    patient = Patient_col.find_one(query)
    return render_template("patient_home.html", patient=patient)


@app.route("/view_doctors")
def view_doctors():
    doctors = Doctor_col.find()
    return render_template("view_doctors.html", doctors=doctors)


@app.route("/verify_doctor")
def verify_doctor():
    doctor_id = request.args.get("doctor_id")
    query = {"_id": ObjectId(doctor_id)}
    query1 = {"$set": {"status": "Verified"}}
    Doctor_col.update_one(query, query1)
    return redirect("view_doctors")


@app.route("/un_verify_doctor")
def un_verify_doctor():
    doctor_id = request.args.get("doctor_id")
    query = {"_id": ObjectId(doctor_id)}
    query1 = {"$set": {"status": "Not Verified"}}
    Doctor_col.update_one(query, query1)
    return redirect("view_doctors")


@app.route("/medicine_category")
def medicine_category():
    categories = Medicine_category.find()
    return render_template("medicine_category.html", categories=categories)


@app.route("/add_category")
def add_category():
    category_name = request.args.get("category_name")
    query = {"category_name": category_name}
    count = Medicine_category.count_documents(query)
    if count == 0:
        query = {"category_name": category_name}
        Medicine_category.insert_one(query)
        return redirect("medicine_category")
    else:
        return render_template("message.html", msg="Duplicate category name")


@app.route("/add_medicine")
def medicine():
    categories = Medicine_category.find()
    return render_template("add_medicine.html", categories=categories)


@app.route("/add_medicine1", methods=['post'])
def add_medicine1():
    category_id = request.form.get("category_id")
    Is_prescription_required = request.form.get("Is_prescription_required")
    brand = request.form.get("brand")
    price = request.form.get("price")
    name = request.form.get("name")
    picture = request.files.get("picture")
    path = APP_ROOT + "/static/" + picture.filename
    picture.save(path)
    query = {"name": name}
    count = Medicine_col.count_documents(query)
    if count == 0:
        query = {"category_id": ObjectId(category_id), "name": name,
                 "Is_prescription_required": Is_prescription_required, "brand": brand, "price": price,
                 "picture": picture.filename}
        Medicine_col.insert_one(query)
        return render_template("message.html", msg="Medicine Added!")
    else:
        return render_template("message.html", msg="Medicine already added")


@app.route("/view_medicine")
def view_medicine():
    medicines = Medicine_col.find()
    return render_template("view_medicine.html", medicines=medicines)


@app.route("/search_medicine")
def search_medicine():
    if session['role'] == 'doctor':
        patient_id = request.args.get("patient_id")
        print(patient_id, "patient")
        medicine_categories = Medicine_category.find()
        return render_template("search_medicine.html", medicine_categories=medicine_categories, patient_id=patient_id)
    else:
        medicine_categories = Medicine_category.find()
        return render_template("search_medicine.html", medicine_categories=medicine_categories)


@app.route("/get_medicine")
def get_medicine():
    medicine_category_id = request.args.get("medicine_category_id")
    medicine_name = request.args.get("medicine_name")
    if medicine_category_id is None:
        medicine_category_id = ''
    if medicine_name is None:
        medicine_name = ''
    if medicine_category_id == '' and medicine_name == '':
        query = {}
    elif medicine_category_id != '' and medicine_name == '':
        query = {"category_id": ObjectId(medicine_category_id)}
    elif medicine_category_id == '' and medicine_name != '':
        rgx = re.compile(".*" + medicine_name + ".*", re.IGNORECASE)
        query = {"name": rgx}
    elif medicine_category_id != '' and medicine_name != '':
        rgx = re.compile(".*" + medicine_name + ".*", re.IGNORECASE)
        query = {"category_id": ObjectId(medicine_category_id), "name": rgx}
    medicines = Medicine_col.find(query)
    patient_id = request.args.get("patient_id")
    print("vachindhi", patient_id)
    if patient_id is not None:
        return render_template("patient_view_medicine.html", medicines=medicines, patient_id=patient_id)
    return render_template("patient_view_medicine.html", medicines=medicines)


@app.route("/quantity")
def quantity():
    medicine_id = request.args.get("medicine_id")
    query = {"_id": ObjectId(medicine_id)}
    patient_id = request.args.get("patient_id")
    if patient_id is None:
        return render_template("quantity.html", medicine_id=medicine_id)
    else:
        return render_template("quantity.html", medicine_id=medicine_id, patient_id=patient_id)

@app.route("/add_prescription", methods = ['post'])
def add_prescription():
    medicine_id = request.form.get("medicine_id")
    quantity = request.form.get("quantity")
    doctor_id = session['doctor_id']
    patient_id = request.form.get("patient_id")
    print(patient_id)
    query = {"doctor_id": ObjectId(doctor_id), "status": "Preparing Prescription"}
    count = Prescription_col.count_documents(query)
    if count > 0 :
        Prescription = Prescription_col.find_one(query)
        prescription_id = Prescription['_id']
    else:
        query = {"doctor_id": ObjectId(doctor_id), "status": "Preparing Prescription", "date": datetime.datetime.now(), "patient_id": ObjectId(patient_id)  }
        result = Prescription_col.insert_one(query)
        prescription_id = result.inserted_id
    query = {"_id": ObjectId(prescription_id), "Prescribered_medicine.medicine_id": ObjectId(medicine_id)}
    count = Prescription_col.count_documents(query)
    if count == 0:
        query1 = {"_id": ObjectId(prescription_id)}
        query2 = {"$push": {"Prescribered_medicine": {"medicine_id": ObjectId(medicine_id), "quantity": int(quantity)}}}
        Prescription_col.update_one(query1, query2)
        # render_template("message.html", message="Medicine Added to cart")
        redirect("view_prescription_to_doctor_patient?value=Preparing Prescription")
    else:
        Prescription = Prescription_col.find_one(query, {"Prescribered_medicine.$": 1})
        query2 = {"$set": {"Prescribered_medicine.$.quantity": int(Prescription['Prescribered_medicine'][0]['quantity']) + int(quantity)}}
        Prescription_col.update_one(query, query2)
    # return render_template("message.html", message="Medicine Updated to cart")
    return redirect("view_prescription_to_doctor_patient?value=Preparing Prescription")


@app.route("/add_to_cart")
def add_to_cart():
    medicine_id = request.args.get("medicine_id")
    if session['role'] == 'patient':
        patient_id = session['patient_id']
        print(type(patient_id))
        quantity = request.args.get("quantity")
        query = {"patient_id": ObjectId(patient_id), "status": "cart"}
        count = Order_col.count_documents(query)
        if count > 0:
            order = Order_col.find_one(query)
            order_id = order['_id']
        else:
            query = {"patient_id": ObjectId(patient_id), "status": "cart", "date": datetime.datetime.now()}
            result = Order_col.insert_one(query)
            order_id = result.inserted_id
    elif session['role'] == 'doctor':
        patient_id = request.args.get("patient_id")
        print(patient_id)
        doctor_id = session['doctor_id']
        quantity = request.args.get("quantity")
        query = {"patient_id": ObjectId(patient_id), "doctor_id": ObjectId(doctor_id), "status": "Prescription Preparing"}
        result_id = Prescription_col.insert_one(query)
        prescription_id = result_id.inserted_id
        print("pres", prescription_id)
        query1 = {"prescription_id": ObjectId(prescription_id)}
        count = Order_col.count_documents(query1)
        if count > 0:
            order = Order_col.find_one(query)
            order_id = order['_id']
        else:
            query = {"patient_id": ObjectId(patient_id), "prescription_id": ObjectId(prescription_id), "status": "Prescription Preparing", "order_type": "prescribed", "date": datetime.datetime.now()}
            result = Order_col.insert_one(query)
            order_id = result.inserted_id
    query = {"_id": ObjectId(order_id), "medicines.medicine_id": ObjectId(medicine_id)}
    count = Order_col.count_documents(query)
    if count == 0:
        query1 = {"_id": ObjectId(order_id)}
        query2 = {"$push": {"medicines": {"medicine_id": ObjectId(medicine_id), "quantity": int(quantity)}}}
        Order_col.update_one(query1, query2)
        return render_template("message.html", msg="Product Added to cart")
    else:
        order = Order_col.find_one(query, {"medicines.$": 1})
        query2 = {"$set": {"medicines.$.quantity": int(order['medicines'][0]['quantity']) + int(quantity)}}
        Order_col.update_one(query, query2)
        return render_template("message.html", msg="Product Updated to cart")


@app.route("/view_cart")
def view_cart():
    status = request.args.get("status")
    query = {}
    if session['role'] == 'patient':
        patient_id = session['patient_id']
        if status == "cart":
            query = {"$or": [{"patient_id": ObjectId(patient_id), "status": "cart"}, {"patient_id": ObjectId(patient_id), "status": "Prescription Sent to Admin"}]}
            orders = Order_col.find(query)
        elif status == "ordered":
            query = {"$or": [{"patient_id": ObjectId(patient_id), "status": "Order Placed"},
                             {"patient_id": ObjectId(patient_id), "status": "order dispatched"},
                             {"patient_id": ObjectId(patient_id), "status": "Assigned to delivery boy"},
                             {"patient_id": ObjectId(patient_id), "status": "Out for delivery"}]}
            orders = Order_col.find(query)
        elif status == "delivered":
            query = {"$or": [{"patient_id": ObjectId(patient_id), "status": "Order Delivered"}, {"patient_id": ObjectId(patient_id), "status": "Order Cancelled"}, {"patient_id": ObjectId(patient_id), "status": "Order Rejected"}]}
            orders = Order_col.find(query)
    if session['role'] == 'Admin':
        if status == "ordered":
            query = {"$or": [{"status": "Order Placed"}, {"status": "Prescription Sent to Admin"}]}
            orders = Order_col.find(query)
        elif status == "processing":
            query = {"status": {"$nin": ['cart', 'Order Placed', 'Order Delivered', 'Order Cancelled', 'Order Rejected']}}
            orders = Order_col.find(query)
        elif status == "delivered":
            query = {"$or": [{"status": "Order Delivered"}, {"status": "Order Cancelled"}, {"status": "Order Rejected"}]}
            orders = Order_col.find(query)
    if session['role'] == 'delivery boy':
        if status == "ordered":
            delivery_boy_id = session['delivery_boy_id']
            query = {"$or": [{"delivery_boy_id": ObjectId(delivery_boy_id), "status": "Assigned to delivery boy"}, {"delivery_boy_id": ObjectId(delivery_boy_id), "status": "Out for delivery"}, {"delivery_boy_id": ObjectId(delivery_boy_id), "status": "Order Delivered"}]}
            delivery_boys = Delivery_boy_col.find()
    if session['role'] == 'doctor':
        if status == "cart":
            doctor_id = session['doctor_id']
            patient_id = request.args.get("patient_id")
            query = {"$or": [{"doctor_id": ObjectId(doctor_id), "status": "Prescription Preparing"}, {"status": "Prescription Sent to Patient"}, {"status": "Prescription Given"}]}
    orders = Order_col.find(query)
    orders = list(orders)
    orders.reverse()
    delivery_boys = Delivery_boy_col.find()
    if session['role'] == 'doctor':
        if patient_id is not None:
            return render_template("view_cart.html", patient_id=patient_id, delivery_boys=delivery_boys, get_prescription_by_id=get_prescription_by_id, orders=orders, get_medicine_name=get_medicine_name, get_category=get_category, int=int, get_prescription_details=get_prescription_details, get_patient_by_patient_id=get_patient_by_patient_id)
    else:
        return render_template("view_cart.html", delivery_boys=delivery_boys,
                               get_prescription_by_id=get_prescription_by_id, orders=orders,
                               get_medicine_name=get_medicine_name, get_category=get_category, int=int,
                               get_prescription_details=get_prescription_details,
                               get_patient_by_patient_id=get_patient_by_patient_id)


def get_medicine_name(medicine_id):
    query = {"_id": ObjectId(medicine_id)}
    medicine = Medicine_col.find_one(query)
    return medicine


def get_patient_by_patient_id(patient_id):
    query = {"_id": patient_id}
    patient = Patient_col.find_one(query)
    return patient


def get_category(category_id):
    query = {"_id": ObjectId(category_id)}
    category = Medicine_category.find_one(query)
    return category


@app.route("/remove")
def remove():
    medicine_id = request.args.get("medicine_id")
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$pull": {"medicines": {"medicine_id": ObjectId(medicine_id)}}}
    Order_col.update_one(query, query1)
    query = {"_id": ObjectId(order_id)}
    order = Order_col.find_one(query)
    medicines = order['medicines']
    print(len(medicines))
    if len(medicines) == 0:
        query = {"_id": ObjectId(order_id)}
        Order_col.delete_one(query)
        return render_template("message.html", msg="Items removed")
    return redirect("view_cart")


def get_prescription_details(order_id):
    Is_prescription_needed = False
    query = {"_id": ObjectId(order_id)}
    order = Order_col.find_one(query)
    medicines = order['medicines']
    for medicine in medicines:
        medicine_id = medicine['medicine_id']
        med = Medicine_col.find_one(medicine_id)
        if med['Is_prescription_required'] == "Yes":
            Is_prescription_needed = True
    return Is_prescription_needed


@app.route("/send_prescription")
def send_prescription():
    order_id = request.args.get("order_id")
    order = {"_id": ObjectId(order_id)}
    prescription_id = order['_id']
    print(prescription_id)
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "cart", "prescription_id": ObjectId(prescription_id)}}
    Order_col.update_one(query, query1)
    return render_template("message.html", msg="Prescription sent to patient!")


@app.route("/place_order", methods=['post'])
def place_order():
    order_id = request.form.get("order_id")
    total_amount = request.form.get("total_amount")
    prescription = request.files.get("prescription")
    if prescription is None:
        filename = ""
    else:
        filename = prescription.filename
    path = APP_ROOT + "/static/" + filename
    try:
        prescription.save(path)
    except:
        pass
    delivery_type = request.form.get("delivery_type")
    order_type = request.form.get("order_type")
    patient_id = session['patient_id']
    query = {"_id": ObjectId(order_id)}
    if prescription is not None:
        query1 = {"$set": {"patient_id": ObjectId(patient_id), order_type: "Prescribed", "delivery_type": delivery_type,
                       "total_amount": total_amount, "status": "Payment Pending", "prescription": prescription.filename}}
    elif prescription is None:
        query1 = {"$set": {"patient_id": ObjectId(patient_id), "order_type": "Non Prescribed", "delivery_type": delivery_type,
                           "total_amount": total_amount, "status": "Payment Pending"}}
    Order_col.update_one(query, query1)
    return render_template("payment.html", total_amount=total_amount, order_id=order_id)


@app.route("/payment_done")
def payment_done():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "Order Placed"}}
    Order_col.update_one(query, query1)
    card_number = request.args.get("card_number")
    card_holder = request.args.get("card_holder")
    total_amount = request.args.get("total_amount")
    date = datetime.datetime.now()
    query = {"order_id": order_id, "date": date, "card_number": card_number, "card_holder": card_holder, "Amount": total_amount}
    Payment_col.insert_one(query)
    return render_template("message.html", msg="Order Placed Successfully!")


@app.route("/view_orders")
def view_orders():
    query = {}
    if session['role'] == "Admin":
        query = {}
    elif session['role'] == "patient":
        patient_id = session['patient_id']
        query = {"patient_id": ObjectId(patient_id)}
    orders = Order_col.find(query)
    return render_template("view_orders.html", orders=orders, get_customer_details=get_customer_details)


def get_customer_details(patient_id):
    query = {"_id": ObjectId(patient_id)}
    patient = Patient_col.find_one(query)
    return patient


@app.route("/dispatch_order")
def dispatch_order():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "order dispatched"}}
    Order_col.update_one(query, query1)
    return redirect("view_cart")


@app.route("/cancel_order")
def cancel_order():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "Order Cancelled"}}
    Order_col.update_one(query, query1)
    return redirect("view_cart")


@app.route("/pickup_order")
def pickup_order():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "Order Delivered"}}
    Order_col.update_one(query, query1)
    return redirect("view_cart")


@app.route("/deliver_order")
def deliver_order():
    order_id = request.args.get("order_id")
    print("orderid", order_id)
    delivery_boy_id = request.args.get("delivery_boy_id")
    print(delivery_boy_id, "delivery boy")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "Assigned to delivery boy", "delivery_boy_id": ObjectId(delivery_boy_id)}}
    Order_col.update_one(query, query1)
    return render_template("message.html", msg="Order assigned to delivery boy")


@app.route("/receive_order")
def receive_order():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "Order Delivered"}}
    Order_col.update_one(query, query1)
    return redirect("view_cart")


@app.route("/out_for_delivery")
def out_for_delivery():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "Out for delivery"}}
    Order_col.update_one(query, query1)
    return redirect("view_cart")


@app.route("/search_patient")
def search_patient():
    return render_template("search_patient.html")


@app.route("/get_patients")
def get_patients():
    patient_name = request.args.get("patient_name")
    if patient_name is None:
        patient_name = ''
    if patient_name == '':
        query = {}
    elif patient_name != '':
        rgx = re.compile(".*" + patient_name + ".*", re.IGNORECASE)
        query = {"name": rgx}
    patients = Patient_col.find(query)
    return render_template("view_patients.html", patients=patients)

@app.route("/write_prescription")
def write_prescription():
    patient_id = request.args.get("patient_id")
    return render_template("write_prescription.html", patient_id=patient_id)


@app.route("/prescription", methods=['post'])
def prescription():
    patient_id = request.form.get("patient_id")
    print(patient_id, "please")
    doctor_id = session['doctor_id']
    prescribed_date = datetime.datetime.now()
    start_time = request.form.get("start_time")
    end_date = request.form.get("end_date")
    start_time = start_time.replace("T", " ")
    end_date = end_date.replace("T", " ")
    start_time = datetime.datetime.strptime(start_time, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    start_time = str(start_time.date())
    end_date = str(end_date.date())
    if end_date <= start_time:
        return render_template("message.html", msg="End date should be after start date")
    query = {"patient_id": ObjectId(patient_id), "doctor_id": ObjectId(doctor_id), "prescribed_date": prescribed_date, "start_time": start_time, "end_date": end_date, "status": "Prescription Given"}
    Prescription_col.insert_one(query)
    query = {"patient_id": ObjectId(patient_id), "doctor_id": ObjectId(doctor_id)}
    query1 = {"$set": {"status": "Prescription Given"}}
    Order_col.update_one(query, query1)
    return render_template("message.html", msg="Prescription Added!")


@app.route("/view_prescription")
def view_prescription():
    query = {}
    if session['role'] == 'Admin':
        query = {}
    elif session['role'] == 'patient':
        patient_id = session['patient_id']
        query = {"patient_id": ObjectId(patient_id)}
    prescriptions = Prescription_col.find(query)
    prescriptions = list(prescriptions)
    prescriptions.reverse()
    if prescriptions is None:
        return render_template("message.html", msg="Prescription Not Added!")
    return render_template("view_prescription.html", prescriptions=prescriptions, get_doctor_by_id=get_doctor_by_id)


def get_doctor_by_id(doctor_id):
    query = {"_id": ObjectId(doctor_id)}
    doctor = Doctor_col.find_one(query)
    return doctor


@app.route("/prescribed_order")
def prescribed_order():
    patient_id = session['patient_id']
    prescription_id = request.args.get("prescription_id")
    query = {"patient_id": ObjectId(patient_id), "prescription_id": ObjectId(prescription_id), "status": "Prescription Sent to Admin", "order_type": "prescribed", "date": datetime.datetime.now()}
    Order_col.insert_one(query)
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"status": "Order Created"}}
    Prescription_col.update_one(query, query1)
    return render_template("message.html", msg="Order Placed")


def get_prescription_by_id(prescription_id):
    print(prescription_id)
    query = {"_id": ObjectId(prescription_id)}
    prescription = Prescription_col.find_one(query)
    return prescription


@app.route("/add_medicine_by_admin")
def add_medicine_by_admin():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    order = Order_col.find_one(query)
    patient_id = order['patient_id']
    session['patient_id'] = str(patient_id)
    session['order_id'] = str(order_id)
    return render_template("search_medicine.html")


@app.route("/reject_order")
def reject_order():
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    query1 = {"$set": {"status": "Order Rejected"}}
    Order_col.update_one(query, query1)
    return render_template("message.html", msg="Order Rejected")


@app.route("/send_invoice")
def send_invoice():
    if 'order_id' in session:
        session.pop('order_id')
        session.pop('patient_id')
    order_id = request.args.get("order_id")
    query = {"_id": ObjectId(order_id)}
    order = Order_col.find_one(query)
    if 'medicines' not in order:
        return render_template("message.html", msg="Cannot send invoice")
    query1 = {"$set": {"status": "cart"}}
    Order_col.update_one(query, query1)
    return render_template("message.html", msg="Invoice Sent to patient")


@app.route("/reset_patient_password")
def reset_patient_password():
    return render_template("reset_password.html")


@app.route("/reset_password1")
def reset_password():
    old_password = request.args.get("old_password")
    new_password = request.args.get("new_password")
    if session['role'] == 'doctor':
        doctor_id = session['doctor_id']
        query = {"password": old_password, "_id": ObjectId(doctor_id)}
        count = Doctor_col.count_documents(query)
    elif session['role'] == 'patient':
        patient_id = session['patient_id']
        query = {"password": old_password, "_id": ObjectId(patient_id)}
        count = Patient_col.count_documents(query)
    elif session['role'] == 'delivery boy':
        delivery_boy_id = session['delivery_boy_id']
        query = {"password": old_password, "_id": ObjectId(delivery_boy_id)}
        count = Delivery_boy_col.count_documents(query)
    if old_password == new_password:
        return render_template("message.html", msg="New and Old passwords are same")
    if count == 0:
        return render_template("message.html", msg="Old password is wrong")
    if session['role'] == 'doctor':
        doctor_id = session['doctor_id']
        query = {"_id": ObjectId(doctor_id)}
        query1 = {"$set": {"password": new_password}}
        Doctor_col.update_one(query, query1)
    elif session['role'] == 'patient':
        patient_id = session['patient_id']
        query = {"_id": ObjectId(patient_id)}
        query1 = {"$set": {"password": new_password}}
        Patient_col.update_one(query, query1)
    elif session['role'] == 'delivery boy':
        delivery_boy_id = session['delivery_boy_id']
        query = {"_id": ObjectId(delivery_boy_id)}
        query1 = {"$set": {"password": new_password}}
        Delivery_boy_col.update_one(query, query1)
    return render_template("message.html", msg="Password Updated Successfully!")


def get_doctor(doctor_id):
    query = {"_id": ObjectId(doctor_id)}
    doctor = Doctor_col.find_one(query)
    return doctor

def get_medicine_id(medicine_id):
    query = {"_id": ObjectId(medicine_id)}
    medicine = Medicine_col.find_one(query)
    return medicine

def get_category_id(category_id):
    query = {"_id": ObjectId(category_id)}
    category = Medicine_category.find_one(query)
    return category

@app.route("/remove_medice")
def remove_medice():
    medicine_id = request.args.get("medicine_id")
    prescription_id = request.args.get("prescription_id")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$pull": {"Prescribered_medicine": {"medicine_id": ObjectId(medicine_id)}}}
    Prescription_col.update_one(query, query1)
    Prescription = Prescription_col.find_one(query)
    Prescribered_medicine = Prescription['Prescribered_medicine']
    if len(Prescribered_medicine) == 0:
        query = {"_id": ObjectId(prescription_id)}
        Prescription_col.delete_one(query)
        return render_template("message.html", message="Medicine removed")
    return redirect("view_prescription_to_doctor_patient?value=Preparing Prescription")

@app.route("/send_prescription_to_patient")
def send_prescription_to_patient():
    patient_id = request.args.get("patient_id")
    start_date = request.args.get("start_date")
    end_date = request.args.get("end_date")
    prescription_id = request.args.get("prescription_id")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"patient_id": ObjectId(patient_id),"start_date": start_date, "end_date": end_date, "status": "Prepared Prescription"}}
    Prescription_col.update_one(query,query1)
    return render_template("message.html", msg="Prescription Prepared to Patient")

@app.route("/view_prescription_to_doctor_patient")
def view_prescription_to_doctor_patient():
    value = request.args.get("value")
    query = {}
    if session['role'] == 'doctor':
        doctor_id = session['doctor_id']
        query = {"doctor_id": ObjectId(doctor_id)}
        prescriptions = Prescription_col.find(query)
        if value == 'Preparing Prescription':
            query = {"doctor_id": ObjectId(doctor_id), "status": "Preparing Prescription"}
            prescriptions = Prescription_col.find(query)
        elif value == 'Prepared Prescription':
            query = {"doctor_id": ObjectId(doctor_id), "status": "Prepared Prescription"}
            prescriptions = Prescription_col.find(query)
    elif session['role'] == 'patient':
        patient_id = session['patient_id']
        if value == 'Patient Prepared Prescription':
            query = {"patient_id": ObjectId(patient_id), "status": "Prepared Prescription"}
        elif value == 'Ordered Prescription':
            query = {"patient_id": ObjectId(patient_id), "status": "Ordered Prescription"}
            prescriptions = Prescription_col.find(query)
        elif value == 'Dispatched Order Prescription':
            query = {"patient_id": ObjectId(patient_id), "status": "Dispatched and Ordered Prescription"}
        prescriptions = Prescription_col.find(query)
    elif session['role'] == 'Admin':
        if value == 'Ordered Prescription':
            query = {"status": "Ordered Prescription"}
            prescriptions = Prescription_col.find(query)
        elif value == 'Dispatched Order Prescription':
            query = {"status": "Dispatched and Ordered Prescription"}
            prescriptions = Prescription_col.find(query)
        elif value == 'Assigned to delivery boy':
            query = {"status": "Assigned to delivery boy"}
            prescriptions = Prescription_col.find(query)
    elif session['role'] == 'delivery boy':
        delivery_boy_id = session['delivery_boy_id']
        if value == 'Assigned to delivery boy':
            query = {"delivery_boy_id": ObjectId(delivery_boy_id), "status": "Assigned to delivery boy"}
            prescriptions = Prescription_col.find(query)
        elif value == 'Picked Up':
            query = {"$or": [{"delivery_boy_id": ObjectId(delivery_boy_id), "status": "Picked Up"},{"delivery_boy_id": ObjectId(delivery_boy_id), "status": "Order Delivered"}]}
        prescriptions = Prescription_col.find(query)
    patients = Patient_col.find()
    delivery_boys = Delivery_boy_col.find()
    return render_template("view_prescription_to_doctor_patient.html",prescriptions=prescriptions,get_doctor=get_doctor,get_medicine_id=get_medicine_id,get_category_id=get_category_id,patients=patients,delivery_boys=delivery_boys,int=int)

@app.route("/order_prescription")
def order_prescription():
    prescription_id = request.args.get("prescription_id")
    delivery_type = request.args.get("delivery_type")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"delivery_type": delivery_type, "status": "Ordered Prescription"}}
    Prescription_col.update_one(query,query1)
    # return render_template("message.html", msg="Ordered Prescription Successfully")
    return render_template("payment.html", prescription_id=prescription_id, delivery_type=delivery_type)


@app.route("/dispatch_order_prescription")
def dispatch_order_prescription():
    prescription_id = request.args.get("prescription_id")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"status": "Dispatched and Ordered Prescription"}}
    Prescription_col.update_one(query,query1)
    return render_template("message.html", msg="Dispatched Ordered Prescription Successfully")

@app.route("/make_ordered_prescription_delivered")
def make_ordered_prescription_delivered():
    prescription_id = request.args.get("prescription_id")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"status": "Prescription Order Delivered"}}
    Prescription_col.update_one(query,query1)
    return render_template("message.html", msg="Ordered Prescription Delivered Successfully")

@app.route("/admin_deliver_order")
def admin_deliver_order():
    prescription_id = request.args.get("prescription_id")
    delivery_boy_id = request.args.get("delivery_boy_id")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"status": "Assigned to delivery boy", "delivery_boy_id": ObjectId(delivery_boy_id)}}
    Prescription_col.update_one(query, query1)
    return render_template("message.html", msg="Order assigned to delivery boy")

@app.route("/pick_up")
def pick_up():
    prescription_id = request.args.get("prescription_id")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"status": "Picked Up"}}
    Prescription_col.update_one(query,query1)
    return render_template("message.html", msg="Dispatched Order Successfully")

@app.route("/make_as_ordered_delivered")
def make_as_ordered_delivered():
    prescription_id = request.args.get("prescription_id")
    query = {"_id": ObjectId(prescription_id)}
    query1 = {"$set": {"status": "Order Delivered"}}
    Prescription_col.update_one(query,query1)
    return render_template("message.html", msg="Order Delivered Successfully")

app.run(debug=True,port=5001)
